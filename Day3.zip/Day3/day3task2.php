<?php
		$Fname=$_POST['Fname'];
		$Lname=$_POST['Lname'];
		$clgname=$_POST['clgname'];
		$erno=$_POST['erno'];	
		$email=$_POST['email'];
		$mad=$_POST['mad'];	
		$mc&wc=$_POST['mc&wc'];	
		$is=$_POST['is'];
		$bda=$_POST['bda'];	
		$total=($mad+$mc&wc+$is+$bda);
		$average=($total/4);
		echo "First Name is:".$Fname."<br>";
		echo "Last Name is:".$Lname."<br>";
		echo "College Name is:".$clgname."<br>";
		echo "Enrollment Number is:".$erno."<br>";
		echo "Email is:".$email."<br>";
		echo "MAD 's mark is:".$mad."<br>";
		echo "MC&WC 's mark is:".$mc&wc."<br>";
		echo "IS 's mark is:".$is."<br>";
		echo "BDA 's mark is:".$bda."<br>";
		echo "Total is:".$total."<br>";
		echo "Average is:".$average	."<br>";
		if($average>80){
			echo "First class with Distinction";
		}
		elseif($average>70){
			echo "First class";
		}
		elseif($average>60){
			echo "Second class";
		}
		elseif($average>50){
			echo "Pass class";
		}
		else{
			echo"Try better next time";
		}

?>