<?php
		if(isset($_POST['submit']))
		{
			$Fname=$_POST['Fname'];
			$Lname=$_POST['Lane'];
			$sem=$_POST['sem'];
			$branch=$_POST['branch'];	
			$erno=$_POST['erno'];	
			$clgname=$_POST['clgname'];
			$mbno=$_POST['mbno'];


			echo "First Name is:".$Fname."<br>";
			echo "Last Name is:".$Lname."<br>";
			echo "Sem is:".$sem."<br>";
			echo "Branch is:".$branch."<br>";
			echo "Enrollment Number is:".$erno."<br>";
			echo "College Name is:".$clgname."<br>";
			echo "Mobile Number is:".$mbno."<br>";
			
		}
?>